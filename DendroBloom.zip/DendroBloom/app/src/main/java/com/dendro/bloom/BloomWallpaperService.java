package com.dendro.bloom;

import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.service.wallpaper.WallpaperService;
import android.view.MotionEvent;
import android.view.SurfaceHolder;

import java.util.Random;

/**
 * Live wallpaper: a glowing nature-energy ring centred on the OnePlus 11R
 * under-display fingerprint sensor. Vines curl outward, leaves unfurl, the
 * ring blooms into petals, and spores drift upward. Tap the sensor area to
 * trigger an extra bloom.
 */
public class BloomWallpaperService extends WallpaperService {

    /** Vertical position of the fingerprint sensor as a fraction of screen height.
     *  0.865 matches the OnePlus 11R; nudge it if the ring sits off-centre. */
    static final float SENSOR_Y = 0.865f;

    static final int GREEN_CORE = Color.rgb(190, 255, 120);
    static final int GREEN_GLOW = Color.rgb(90, 220, 70);
    static final int GREEN_DEEP = Color.rgb(30, 120, 40);
    static final int GOLD = Color.rgb(240, 230, 140);

    @Override public Engine onCreateEngine() { return new BloomEngine(); }

    class BloomEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Runnable frame = this::drawFrame;
        private boolean visible;
        private int w, h;
        private float cx, cy, unit;
        private final long start = SystemClock.uptimeMillis();
        private long tapTime = -100000;

        private final Paint bg = new Paint();
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint core = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fillGlow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path path = new Path();
        private final RectF oval = new RectF();

        private static final int SPORES = 46;
        private final float[] sx = new float[SPORES], sy = new float[SPORES],
                sv = new float[SPORES], sp = new float[SPORES], ss = new float[SPORES];
        private final Random rnd = new Random();

        BloomEngine() {
            glow.setStyle(Paint.Style.STROKE);
            glow.setStrokeCap(Paint.Cap.ROUND);
            core.setStyle(Paint.Style.STROKE);
            core.setStrokeCap(Paint.Cap.ROUND);
            fill.setStyle(Paint.Style.FILL);
            fillGlow.setStyle(Paint.Style.FILL);
        }

        @Override public void onCreate(SurfaceHolder holder) {
            super.onCreate(holder);
            setTouchEventsEnabled(true);
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            w = width; h = height;
            cx = w / 2f; cy = h * SENSOR_Y;
            unit = w / 1240f; // OnePlus 11R is 1240 px wide
            glow.setMaskFilter(new BlurMaskFilter(14 * unit, BlurMaskFilter.Blur.NORMAL));
            fillGlow.setMaskFilter(new BlurMaskFilter(18 * unit, BlurMaskFilter.Blur.NORMAL));
            bg.setShader(new RadialGradient(cx, cy, h * 0.75f,
                    new int[]{Color.rgb(16, 46, 22), Color.rgb(6, 20, 10), Color.rgb(2, 6, 4)},
                    new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
            for (int i = 0; i < SPORES; i++) respawn(i, true);
            drawFrame();
        }

        @Override public void onVisibilityChanged(boolean v) {
            visible = v;
            if (v) drawFrame(); else handler.removeCallbacks(frame);
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            super.onSurfaceDestroyed(holder);
            visible = false;
            handler.removeCallbacks(frame);
        }

        @Override public void onDestroy() {
            super.onDestroy();
            handler.removeCallbacks(frame);
        }

        @Override public void onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                float dx = e.getX() - cx, dy = e.getY() - cy;
                if (dx * dx + dy * dy < (260 * unit) * (260 * unit)) {
                    tapTime = SystemClock.uptimeMillis();
                }
            }
        }

        private void respawn(int i, boolean anywhere) {
            float a = rnd.nextFloat() * 6.2832f;
            float r = (120 + rnd.nextFloat() * 260) * unit;
            sx[i] = cx + (float) Math.cos(a) * r;
            sy[i] = anywhere ? cy - rnd.nextFloat() * h * 0.7f : cy + (float) Math.sin(a) * r * 0.5f;
            sv[i] = (25 + rnd.nextFloat() * 55) * unit;     // rise speed px/s
            sp[i] = rnd.nextFloat() * 6.2832f;              // sway phase
            ss[i] = (2.5f + rnd.nextFloat() * 5f) * unit;   // size
        }

        private void drawFrame() {
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) render(c);
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) { }
                }
            }
            handler.removeCallbacks(frame);
            if (visible) handler.postDelayed(frame, 16);
        }

        private float lastT = 0;

        private void render(Canvas c) {
            float t = (SystemClock.uptimeMillis() - start) / 1000f;
            float dt = Math.min(0.05f, t - lastT);
            lastT = t;

            c.drawRect(0, 0, w, h, bg);

            float cycle = 4.5f;
            float p = (t % cycle) / cycle;                 // 0..1 loop
            float grow = ease(clamp(p / 0.6f));            // vines grow during first 60%
            float bloom = clamp((p - 0.6f) / 0.4f);        // bloom during last 40%
            float tapAge = (SystemClock.uptimeMillis() - tapTime) / 1000f;
            float tapBloom = tapAge < 1.4f ? tapAge / 1.4f : -1f;
            float breathe = 0.5f + 0.5f * (float) Math.sin(t * 2.4f);

            drawAura(c, breathe, tapBloom);
            drawVines(c, t, grow, 1f - clamp((bloom - 0.7f) / 0.3f));
            drawFingerprint(c, t, breathe);
            if (bloom > 0) drawBloom(c, bloom, t);
            if (tapBloom >= 0) drawBloom(c, tapBloom, t + 1.3f);
            drawSpores(c, t, dt);
        }

        // ---- soft halo behind the sensor ----
        private void drawAura(Canvas c, float breathe, float tap) {
            float r = (150 + 25 * breathe + (tap >= 0 ? 80 * (1 - tap) : 0)) * unit;
            fillGlow.setColor(GREEN_DEEP);
            fillGlow.setAlpha((int) (90 + 60 * breathe));
            c.drawCircle(cx, cy, r, fillGlow);
        }

        // ---- fingerprint ridges: broken concentric arcs that slowly rotate ----
        private void drawFingerprint(Canvas c, float t, float breathe) {
            for (int i = 0; i < 6; i++) {
                float r = (22 + i * 15) * unit;
                oval.set(cx - r * 0.86f, cy - r, cx + r * 0.86f, cy + r);
                float startA = (i % 2 == 0 ? 1 : -1) * t * (14 + i * 4) + i * 47;
                float sweep = 250 + 30 * (float) Math.sin(t * 1.3f + i);
                setStroke(glow, GREEN_GLOW, 9 * unit, (int) (150 + 80 * breathe));
                c.drawArc(oval, startA, sweep, false, glow);
                setStroke(core, GREEN_CORE, 3 * unit, 235);
                c.drawArc(oval, startA, sweep, false, core);
            }
            // outer leaf-shaped emblem ring
            float r = 128 * unit;
            setStroke(glow, GREEN_GLOW, 14 * unit, (int) (120 + 90 * breathe));
            c.drawCircle(cx, cy, r, glow);
            setStroke(core, GREEN_CORE, 2.5f * unit, 220);
            c.drawCircle(cx, cy, r, core);
            // four small diamond buds on the ring
            for (int k = 0; k < 4; k++) {
                double a = Math.toRadians(45 + k * 90 + t * 10);
                float bx = cx + (float) Math.cos(a) * r, by = cy + (float) Math.sin(a) * r;
                drawLeaf(c, bx, by, (float) Math.toDegrees(a), 16 * unit, 255);
            }
        }

        // ---- five vines spiralling out with leaves unfurling along them ----
        private void drawVines(Canvas c, float t, float grow, float fade) {
            if (grow <= 0.01f || fade <= 0) return;
            int vines = 5;
            float r0 = 135 * unit, r1 = 330 * unit;
            for (int v = 0; v < vines; v++) {
                float base = (float) Math.toRadians(v * 72 - 90 + t * 6);
                int steps = 40;
                int n = Math.max(2, (int) (steps * grow));
                path.reset();
                float px = 0, py = 0, pa = 0;
                for (int s = 0; s <= n; s++) {
                    float f = s / (float) steps;
                    float r = r0 + (r1 - r0) * f;
                    float a = base + 1.4f * f + 0.25f * (float) Math.sin(f * 7 + t * 1.5f + v);
                    float x = cx + (float) Math.cos(a) * r;
                    float y = cy + (float) Math.sin(a) * r * 0.92f;
                    if (s == 0) path.moveTo(x, y); else path.lineTo(x, y);
                    pa = (float) Math.toDegrees(Math.atan2(y - py, x - px));
                    px = x; py = y;
                }
                float width = 7 * unit;
                setStroke(glow, GREEN_GLOW, width * 2.2f, (int) (140 * fade));
                c.drawPath(path, glow);
                setStroke(core, GREEN_CORE, width * 0.55f, (int) (230 * fade));
                c.drawPath(path, core);

                // leaves sprout at fixed points once the vine passes them
                float[] at = {0.25f, 0.5f, 0.72f, 0.9f};
                for (int k = 0; k < at.length; k++) {
                    float f = at[k];
                    if (grow < f) continue;
                    float open = clamp((grow - f) / 0.18f);
                    float r = r0 + (r1 - r0) * f;
                    float a = base + 1.4f * f + 0.25f * (float) Math.sin(f * 7 + t * 1.5f + v);
                    float x = cx + (float) Math.cos(a) * r;
                    float y = cy + (float) Math.sin(a) * r * 0.92f;
                    float side = (k % 2 == 0) ? 60 : -60;
                    float ang = (float) Math.toDegrees(a) + 90 + side;
                    drawLeaf(c, x, y, ang, (26 - k * 3) * unit * ease(open), (int) (255 * fade));
                }
                // glowing bud at the tip
                fillGlow.setColor(GREEN_CORE);
                fillGlow.setAlpha((int) (200 * fade));
                c.drawCircle(px, py, 10 * unit, fillGlow);
                fill.setColor(Color.WHITE);
                fill.setAlpha((int) (230 * fade));
                c.drawCircle(px, py, 3.5f * unit, fill);
            }
        }

        // ---- petal burst + expanding shockwave ----
        private void drawBloom(Canvas c, float b, float t) {
            float e = ease(b);
            float fade = 1f - b;
            float ring = (130 + 260 * e) * unit;
            setStroke(glow, GOLD, 18 * unit * fade + 2, (int) (200 * fade));
            c.drawCircle(cx, cy, ring, glow);
            setStroke(core, Color.WHITE, 3 * unit, (int) (220 * fade));
            c.drawCircle(cx, cy, ring, core);

            int petals = 8;
            for (int i = 0; i < petals; i++) {
                double a = Math.toRadians(i * 360.0 / petals + t * 20);
                float d = (110 + 120 * e) * unit;
                float x = cx + (float) Math.cos(a) * d, y = cy + (float) Math.sin(a) * d;
                drawLeaf(c, x, y, (float) Math.toDegrees(a), 44 * unit * (0.6f + 0.6f * e), (int) (255 * fade));
            }
            fillGlow.setColor(GOLD);
            fillGlow.setAlpha((int) (180 * fade));
            c.drawCircle(cx, cy, 70 * unit * (1 + e), fillGlow);
        }

        // ---- drifting spores ----
        private void drawSpores(Canvas c, float t, float dt) {
            for (int i = 0; i < SPORES; i++) {
                sy[i] -= sv[i] * dt;
                float x = sx[i] + (float) Math.sin(t * 1.2f + sp[i]) * 18 * unit;
                float lifeY = (cy - sy[i]) / (h * 0.75f);
                if (lifeY > 1f || sy[i] < 0) { respawn(i, false); continue; }
                float a = clamp(1f - lifeY) * (0.6f + 0.4f * (float) Math.sin(t * 3 + sp[i]));
                fillGlow.setColor(GREEN_GLOW);
                fillGlow.setAlpha((int) (160 * a));
                c.drawCircle(x, sy[i], ss[i] * 3f, fillGlow);
                fill.setColor(GREEN_CORE);
                fill.setAlpha((int) (240 * a));
                c.drawCircle(x, sy[i], ss[i], fill);
            }
        }

        /** Pointed leaf, base at (x,y), pointing along angleDeg. */
        private void drawLeaf(Canvas c, float x, float y, float angleDeg, float len, int alpha) {
            if (len < 1 || alpha <= 0) return;
            c.save();
            c.translate(x, y);
            c.rotate(angleDeg);
            path.reset();
            path.moveTo(0, 0);
            path.quadTo(len * 0.5f, -len * 0.42f, len, 0);
            path.quadTo(len * 0.5f, len * 0.42f, 0, 0);
            path.close();
            fillGlow.setColor(GREEN_GLOW);
            fillGlow.setAlpha((int) (alpha * 0.7f));
            c.drawPath(path, fillGlow);
            fill.setColor(GREEN_CORE);
            fill.setAlpha(alpha);
            c.drawPath(path, fill);
            setStroke(core, GREEN_DEEP, Math.max(1, len * 0.06f), alpha);
            c.drawLine(len * 0.08f, 0, len * 0.85f, 0, core); // leaf vein
            c.restore();
        }

        private void setStroke(Paint p, int color, float width, int alpha) {
            p.setColor(color);
            p.setStrokeWidth(width);
            p.setAlpha(Math.max(0, Math.min(255, alpha)));
        }
    }

    static float clamp(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }
    static float ease(float v) { return 1 - (1 - v) * (1 - v) * (1 - v); }
}
